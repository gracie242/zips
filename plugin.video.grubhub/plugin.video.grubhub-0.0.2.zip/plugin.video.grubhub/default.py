# -*- coding: utf-8 -*-




# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Addon: Grub Hub
# Author: Gracie


import os           
import xbmc      
import xbmcaddon    
import xbmcplugin   





from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File




debug        = Addon_Setting(setting='debug')      
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

BASE  = "plugin://plugin.video.youtube/playlist/"


YOUTUBE_CHANNEL_ID_1 = "PLpWkpVzac-Pp1wQzkIvSjx6dyAA3q0M1I"
YOUTUBE_CHANNEL_ID_2 = "PLpWkpVzac-Pqdih4lugbWrW9ey1sqonnT"
YOUTUBE_CHANNEL_ID_3 = "PLpWkpVzac-PpChmP7iPQEEZw3mjJkUOXO"
YOUTUBE_CHANNEL_ID_4 = "PLpWkpVzac-PoqQVrt8u99BrLlV3TWgJIe"
YOUTUBE_CHANNEL_ID_5 = "PLpWkpVzac-PrIs0pcm-e9BnTlXkxqbyaC"
YOUTUBE_CHANNEL_ID_6 = "PLpWkpVzac-PpVB7-WoBn0We0j7EIRWEs6"
YOUTUBE_CHANNEL_ID_7 = "PLpWkpVzac-PpRdXSAa-A8XURgnywdXNYI"
YOUTUBE_CHANNEL_ID_8 = "PLpWkpVzac-Poxyw8gxE8tbYXFLK6LiV6V"
YOUTUBE_CHANNEL_ID_9 = "PLpWkpVzac-PoXP5pdyOTp-mUcBWrVV6_S"


@route(mode='main_menu')
def Main_Menu():
	Add_Dir( 
        name="Paula Dean", url=BASE+YOUTUBE_CHANNEL_ID_1+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRlciVoCVtwYdjWNReDX631MLpoZi8OYh5JKgOHRBQRwetCbw86xA")
		
	Add_Dir( 
        name="Pit Boys", url=BASE+YOUTUBE_CHANNEL_ID_2+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQkHdK8AIbMZzxkn7uGYCsLXK1XqrzJCQYtVSm-Id86lfQrIqZdpA")
		
	Add_Dir( 
		name="Tasty", url=BASE+YOUTUBE_CHANNEL_ID_3+"/", folder=True,
		icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRc4FphcEp6sKx7KvvsnDP0_Fsr18bw10UunrjlJBjFLzNjz1PSbQ")
	
	Add_Dir( 
		name="Alton Brown", url=BASE+YOUTUBE_CHANNEL_ID_4+"/", folder=True,
		icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSfhr4YYuEbm96vu88cmBR2raF0_gytapLFUqCCzo4FmfbIBLJfxw")
		
	Add_Dir( 
		name="Rachel Ray", url=BASE+YOUTUBE_CHANNEL_ID_5+"/", folder=True,
		icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRCovztlTT2EMpuR_KoK52zsEOue0BS7IeFMODxEjV1s-sK9Pvf0g")	
	
	Add_Dir( 
        name="Emeril", url=BASE+YOUTUBE_CHANNEL_ID_6+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGet2Lj3tCRUNyqOzd1PwEvPIZRRVhE75ScciLPcS7V7G4Kewx5w")
	
	Add_Dir( 
        name="Bobby Flay", url=BASE+YOUTUBE_CHANNEL_ID_7+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSvDq8ie5pbm3chy6D8mNNLF2l5LZTBJhHwmUbTw4zRszvO9D0A")
			
	Add_Dir( 
        name="Gordon", url=BASE+YOUTUBE_CHANNEL_ID_8+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRD4LbMndOAxN8p3-t8CzDJJbu0EqOj48QvM5ISVqtYTA8qwZjn")
		
	Add_Dir( 
        name="Martha", url=BASE+YOUTUBE_CHANNEL_ID_9+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSbv0GL8fs5LrbEyT0ZOMP1s7HI2zG-eR6IK0NS-T0QmPHnK30T")
	



def Koding_Settings():
    Open_Settings()


def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)



if __name__ == "__main__":
    Run(default='main_menu')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))