import re,os,xbmc,urllib,requests

addon_id   = 'plugin.video.goldencinema'

icon      = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart     = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
logfile    = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'log.txt'))

def home(url):
	
	addDir('[COLOR yellow]Adventure[/COLOR]','http://www.bnwmovies.com/genre/adventure',1,icon,fanart,'')
	addDir('[COLOR yellow]Animation[/COLOR]','http://www.bnwmovies.com/genre/animation',1,icon,fanart,'')
	addDir('[COLOR yellow]Comedy[/COLOR]','http://www.bnwmovies.com/genre/comedy',1,icon,fanart,'')
	addDir('[COLOR yellow]Drama[/COLOR]','http://www.bnwmovies.com/genre/drama',1,icon,fanart,'')
	addDir('[COLOR yellow]Horror[/COLOR]','http://www.bnwmovies.com/genre/horror',1,icon,fanart,'')
	addDir('[COLOR yellow]Mystery[/COLOR]','http://www.bnwmovies.com/genre/mystery',1,icon,fanart,'')
	addDir('[COLOR yellow]Romance[/COLOR]','http://www.bnwmovies.com/genre/romance',1,icon,fanart,'')
	addDir('[COLOR yellow]Sci-Fi[/COLOR]','http://www.bnwmovies.com/genre/sci-fi',1,icon,fanart,'')
	addDir('[COLOR yellow]War[/COLOR]','http://www.bnwmovies.com/genre/war',1,icon,fanart,'')
	addDir('[COLOR yellow]Western[/COLOR]','http://www.bnwmovies.com/genre/western',1,icon,fanart,'')
	
def oldmovietimeIndex(url):
	open = requests.get(url,headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36'},verify=False).text
	open = open.encode('utf-8')
	all  = regex_get_all(open,'div class="cattombstone"','</div>')
	for a in all:
		url = regex_from_to(a,'href="','"')
		name= regex_from_to(a,'<br>','</a>')
		icon= regex_from_to(a,'src="','"')
		addDir(name,urllib.quote_plus(url),2,icon,fanart,'')
	try:
		url = regex_from_to(open,'rel="next" href="','"')
		if not url == "" or url.startswith('http'):
			addDir('[COLOR red][B]Next Page[/B][/COLOR]',url,1,icon,fanart,'')
	except:
		pass
		
		
def play(url,name):
	import xbmcgui,xbmcplugin
	open = requests.get(url,headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36'},verify=False).text
	open = open.encode('utf-8')
	
	url  = regex_from_to(open,'<source src="','"')
	
	
	#url = urlresolver.HostedMediaFile(url).resolve()
	
	liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=icon)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': ''})
	liz.setProperty('IsPlayable','true')
	liz.setPath(url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
	


def log(text):
	file = open(logfile,"w+")
	file.write(str(text))

		
def regex_from_to(text, from_string, to_string, excluding=True):
	import re,string
	if excluding:
		try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
		except: r = ''
	else:
		try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
		except: r = ''
	return r


def regex_get_all(text, start_with, end_with):
	import re
	r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
	return r



def addDir(name,url,mode,iconimage,fanart,description):
	import xbmcgui,xbmcplugin,urllib,sys
	u=sys.argv[0]+"?url="+url+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==2:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
	xbmcplugin.endOfDirectory

		

	
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param
params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None
query=None
type=None
# OpenELEQ: query & type-parameter (added 2 lines above)

import urllib

try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass
try:
	description=urllib.unquote_plus(params["description"])
except:
	pass
try:
	query=urllib.unquote_plus(params["query"])
except:
	pass
try:
	type=urllib.unquote_plus(params["type"])
except:
	pass
#OpenELEQ: query & type-parameter (added 8 lines above)	

if mode==None or url==None or len(url)<1:
	home('')
	
elif mode==1:
	oldmovietimeIndex(url)
	
elif mode==2:
	play(url,name)

	
import xbmcplugin
xbmcplugin.endOfDirectory(int(sys.argv[1]))