Could I have it in this order:

Space and exploration
Home shows and overview
Business ideas
Worship and inspirational
Marvel and DC
Sports frenzy 
Fishing and surfing HawaiiPLhgG6tflTqshV-DlIB8RHRkMfndHmI8dA
Hawaiian karaoke
Music
Clash attacks and decks
Cartoons and anime
Special request



Space and Exploration
Home Shows
Business Ideas
Saving money & Life hacksPLhgG6tflTqsiw8GijN6yS7wfhJmme97XB
Worship & Inspiration
Daytime and Latenight talk showsPLhgG6tflTqsgZ6en5jvrvHWkpw5K0m15a
Marvel and DC
Sports Frenzy
Fishing and Surfing Hawaii
Hawaiian Karaoke
Car-e-oke carpool
Music Express
Clash Attacks and Decks
Cartoon and Anime
Special Request