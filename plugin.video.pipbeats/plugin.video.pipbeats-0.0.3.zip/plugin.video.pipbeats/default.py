# -*- coding: utf-8 -*-




# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Addon: Pippy's Beats
# Author: Gracie


import os           
import xbmc      
import xbmcaddon    
import xbmcplugin   





from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File




debug        = Addon_Setting(setting='debug')      
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

BASE  = "plugin://plugin.video.youtube/playlist/"


YOUTUBE_CHANNEL_ID_1 = "PL991qh8jWvSeUqevXF4QH-qHUFnKJ39uQ"
YOUTUBE_CHANNEL_ID_2 = "PL991qh8jWvSdFjgSSWSo7alkpLjkBeOEH"
YOUTUBE_CHANNEL_ID_3 = "PL991qh8jWvSf602_shPxtWdP7_ADuuQQw"
YOUTUBE_CHANNEL_ID_4 = "PL991qh8jWvSeeJQJVD_fYFsUc0v2-N28s"
YOUTUBE_CHANNEL_ID_5 = "PL991qh8jWvSfDiE9jyvvX3W-WJyFPCAhC"
YOUTUBE_CHANNEL_ID_6 = "PL991qh8jWvSd5iD8lBnqxJ_MStwnUsFLE"
YOUTUBE_CHANNEL_ID_7 = "PL991qh8jWvSdEg7omYWW3s3qZRTAot5Oi"


@route(mode='main_menu')
def Main_Menu():
	Add_Dir( 
        name="Toddlers", url=BASE+YOUTUBE_CHANNEL_ID_1+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSUP-otL1RIAWNhwgsWXUWWpBHKV5cKBd5DIZWt_H4kpecACmA6")

	Add_Dir( 
        name="Sesame Street", url=BASE+YOUTUBE_CHANNEL_ID_2+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRdOCJa9wlMMnpvtkWjMt9-VJpvRBpCH2Doesd6IROny-Gmnq_TvQ")
		
	Add_Dir( 
		name="Muppets", url=BASE+YOUTUBE_CHANNEL_ID_3+"/", folder=True,
		icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSxkwR0HgNC9BBX13cd7aB5Xc8cj9a2tF3nb5sgtm9DaKJwrh3X")
	
	Add_Dir( 
		name="Disney", url=BASE+YOUTUBE_CHANNEL_ID_4+"/", folder=True,
		icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQoKWj1-2hX5CUgRCqp4dPP2esmWBaezgvWR-nQs0jtViSyIRm1AA")
		
	Add_Dir( 
		name="Silly Songs", url=BASE+YOUTUBE_CHANNEL_ID_5+"/", folder=True,
		icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSUP-otL1RIAWNhwgsWXUWWpBHKV5cKBd5DIZWt_H4kpecACmA6")	
	
	Add_Dir( 
        name="Educational", url=BASE+YOUTUBE_CHANNEL_ID_6+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS3jPy-BqZkMvUaIGoyAnTr_lR1PkzVMuPbnIgAdqFBorExq6Ft")
	
	Add_Dir( 
        name="My Favorite Music", url=BASE+YOUTUBE_CHANNEL_ID_7+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQoKWj1-2hX5CUgRCqp4dPP2esmWBaezgvWR-nQs0jtViSyIRm1AA")
	


@route(mode='koding_settings')
def Koding_Settings():
    Open_Settings()

@route(mode='simple_dialog', args=['title','msg'])
def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)



if __name__ == "__main__":
    Run(default='main_menu')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))