# -*- coding: utf-8 -*-
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Addon: Blaze
# Author: Gracie and ThunderCat


import os           
import xbmc         
import xbmcaddon    
import xbmcplugin   


from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File

# Added by MuadDib
from koding import Keyboard 
from ytpsearch import *

debug        = Addon_Setting(setting='debug')       
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 


BASE  = "plugin://plugin.video.youtube/playlist/"



YOUTUBE_CHANNEL_ID_1 = "PLpWkpVzac-PqaL7w0-DQ8AM4j0PQsIRHS"
YOUTUBE_CHANNEL_ID_2 = "PLpWkpVzac-PpQCOmHSKDfbM3WbnLEk_lE"
YOUTUBE_CHANNEL_ID_3 = "PLpWkpVzac-PpeC69MZa221b4WUxTedSun"
YOUTUBE_CHANNEL_ID_4 = "PLpWkpVzac-PryD_lkc1LKIC9h_tyQLaV3"
YOUTUBE_CHANNEL_ID_5 = "PLpWkpVzac-PqUxJXAh6VJIU1dXKcyeRjz"
YOUTUBE_CHANNEL_ID_6 = "PLpWkpVzac-PrdkWOUmC3ol3Iy8Bv9PNxw"
YOUTUBE_CHANNEL_ID_7 = "PLpWkpVzac-Pq6Y13ztJeiz1olXkWTqb5I"

# Added by MuadDib
PLAYLISTS = [ YOUTUBE_CHANNEL_ID_1, YOUTUBE_CHANNEL_ID_2, YOUTUBE_CHANNEL_ID_3, YOUTUBE_CHANNEL_ID_4, YOUTUBE_CHANNEL_ID_5, YOUTUBE_CHANNEL_ID_6, YOUTUBE_CHANNEL_ID_7 ]

@route(mode='main_menu')
def Main_Menu():
	
	Add_Dir( 
        name="Hottest Hits", url=BASE+YOUTUBE_CHANNEL_ID_1+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSO1umJOP8CVnwE2NZVsjccd1Duqxa2fNTPpay8WMbPreMRXK3F")
		
	Add_Dir( 
        name="Heavy Metal", url=BASE+YOUTUBE_CHANNEL_ID_2+"/", folder=True,
        icon="https://ichef.bbci.co.uk/images/ic/256x256/p045yy8p.jpg")
	
	Add_Dir( 
        name="Rap", url=BASE+YOUTUBE_CHANNEL_ID_3+"/", folder=True,
        icon="https://ichef.bbci.co.uk/images/ic/256x256/p01k8w4n.jpg")
	
	Add_Dir( 
        name="R&B", url=BASE+YOUTUBE_CHANNEL_ID_4+"/", folder=True,
        icon="https://ichef.bbci.co.uk/images/ic/256x256/p05bbh0z.jpg")
	
	Add_Dir( 
        name="Classic Rock", url=BASE+YOUTUBE_CHANNEL_ID_5+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQXNMD8rtkRor0yyp9XzIWA7zSHz-MintEj0YyYWTKVDpyUK2qg")
	
	Add_Dir( 
        name="Country", url=BASE+YOUTUBE_CHANNEL_ID_6+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-97XykPC9hUYYJX0FOWbPvRz1gEHLXcC2H-pSpfBB-suWbr5eDQ")
	
	Add_Dir( 
        name="Tom Petty", url=BASE+YOUTUBE_CHANNEL_ID_7+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRcFuGUWoOQVBzCViaKJzpv7jiQbyYBPHmk4REcPCco5DtjwUvC9g")

    # Added by MuadDib
	Add_Dir( 
        name="Search", url='plugin://plugin.audio.thundercat?mode=search', folder=False,
        icon="http://www.clker.com/cliparts/f/c/d/7/1349200701375202527Search%20Icon.svg.hi.png")




@route(mode='koding_settings')
def Koding_Settings():
    Open_Settings()

@route(mode='simple_dialog', args=['title','msg'])
def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)

# Added by MuadDib
@route(mode='search')
def Playlist_Search():
    search_term = Keyboard(default='', heading='Search Titles')
    if len(search_term) > 0:
        perform_search(search_term, PLAYLISTS)
    else:
        pass

if __name__ == "__main__":
    Run(default='main_menu')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
