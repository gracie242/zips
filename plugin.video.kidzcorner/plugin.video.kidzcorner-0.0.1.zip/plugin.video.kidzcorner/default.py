# -*- coding: utf-8 -*-
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Addon: Cartoon Crazy
# Author: 56426
import os           
import xbmc      
import xbmcaddon    
import xbmcplugin   
from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File
debug        = Addon_Setting(setting='debug')      
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

BASE  = "plugin://plugin.video.youtube/playlist/"
YOUTUBE_CHANNEL_ID_1 = "PLKmEfdT1xY8IVJAlKaazpd9DvRwtV-Lag"
YOUTUBE_CHANNEL_ID_2 = "PLKmEfdT1xY8K-dRlMWN5XA_uNqcJcqE49"
YOUTUBE_CHANNEL_ID_3 = "PLKmEfdT1xY8J0qdv0Cwd1-3jS2XVfJy8N"
YOUTUBE_CHANNEL_ID_4 = "PLKmEfdT1xY8JOf4thg2S5bgwEn8eyDxGL"
YOUTUBE_CHANNEL_ID_5 = "PLKmEfdT1xY8JiiUlP-n2GZfmVLtMiW3qx"
YOUTUBE_CHANNEL_ID_6 = "PLKmEfdT1xY8K2zEWLHOjzXqE8GODNkx-J"
YOUTUBE_CHANNEL_ID_7 = "PLKmEfdT1xY8IA2EQ7FWfbr63xvh6x4u9R"
YOUTUBE_CHANNEL_ID_8 = "PLKmEfdT1xY8Jd_51b4jpNaPLBTwxb3khU"
YOUTUBE_CHANNEL_ID_9 = "PLKmEfdT1xY8JAP8ZlQqHqC4a0bG0I5VkU"
YOUTUBE_CHANNEL_ID_10 = "PLKmEfdT1xY8K4n8sv9Zx5SM5lkZADTwbt"
YOUTUBE_CHANNEL_ID_11 =	"PLKRTSabSJj40Dx4kTlmxlywmq-er4rJON"
YOUTUBE_CHANNEL_ID_12 = "PL0oL4hnu6SPp8UOy19tKxpLx6fc-tn_Nf"
YOUTUBE_CHANNEL_ID_13 = "PLKmEfdT1xY8Jst-RkOyMHQ9sb3pzJru7B"
YOUTUBE_CHANNEL_ID_14 = "PLKmEfdT1xY8LfDtaQ4h_NMGw8TGav29o5"
YOUTUBE_CHANNEL_ID_15 = "PLKmEfdT1xY8JOMM11coDgNSVbidhGbFBE"
YOUTUBE_CHANNEL_ID_16 = "PLKmEfdT1xY8JMiBxxUkYyf2bkcj9DvbGm"
YOUTUBE_CHANNEL_ID_17 = "PLTfICmEzxkQTPi9yq5uI1GC-9GsG5-jHW"




@route(mode='main_menu')
def Main_Menu():
	Add_Dir( 
        name="PJ Masks", url=BASE+YOUTUBE_CHANNEL_ID_1+"/", folder=True,
        icon="http://www.blogmamma.it/wp-content/uploads/2016/06/festa-a-tema-PJ-Masks-e1465824759467.jpg")

	Add_Dir( 
        name="Poly Pocket", url=BASE+YOUTUBE_CHANNEL_ID_2+"/", folder=True,
        icon="https://pollypocketmyversion.files.wordpress.com/2012/02/polly1.jpg")
		
	Add_Dir( 
		name="TMNT", url=BASE+YOUTUBE_CHANNEL_ID_3+"/", folder=True,
		icon="https://images3.alphacoders.com/239/239779.jpg")
	
	Add_Dir( 
		name="Pocoyo", url=BASE+YOUTUBE_CHANNEL_ID_4+"/", folder=True,
		icon="http://www.freelarge-images.com/wp-content/uploads/2014/12/Pocoyo_images.jpg")
		
	Add_Dir( 
		name="Looney Tunes", url=BASE+YOUTUBE_CHANNEL_ID_5+"/", folder=True,
		icon="https://wallpapercave.com/wp/deV9Jq5.jpg")	
		
	Add_Dir( 
		name="Oggy & The Cockroaches", url=BASE+YOUTUBE_CHANNEL_ID_6+"/", folder=True,
		icon="http://www.wallpaperscharlie.com/wp-content/uploads/2016/09/Oggy-and-The-Cockroaches-Cartoon-HD-Wallpaper-0-1.jpg")
		
	Add_Dir( 
		name="Oddbods", url=BASE+YOUTUBE_CHANNEL_ID_7+"/", folder=True,
		icon="https://3.bp.blogspot.com/-ycAeHD38uOc/VtSKq88EW1I/AAAAAAAAAcc/fQS9rjgDtLM/s1600/Oddbods%2BHD%2BWalpaper334.jpg")
		
	Add_Dir( 
		name="Mr Bean Animated Cartoons", url=BASE+YOUTUBE_CHANNEL_ID_8+"/", folder=True,
		icon="https://livehdwallpaper.com/wp-content/uploads/2016/11/Funny-Mr-Bean-Cartoon-Wallpapers-600x338.jpg")
		
	Add_Dir( 
		name="Mickey Mouse Club House", url=BASE+YOUTUBE_CHANNEL_ID_9+"/", folder=True,
		icon="http://1.bp.blogspot.com/-0d-w1PBTxsI/Tckhw4jo8WI/AAAAAAAAADY/54F5VXAOqzE/s1600/MMCH_Y2_027_001.jpg")
		
	Add_Dir( 
		name="Chip N Dale", url=BASE+YOUTUBE_CHANNEL_ID_10+"/", folder=True,
		icon="http://www.disneypictures.net/data/media/36/chip_and_dale_wallpaper.jpg")
		
	Add_Dir( 
		name="Sofia The First", url=BASE+YOUTUBE_CHANNEL_ID_11+"/", folder=True,
		icon="https://i.ytimg.com/vi/HKm1xPiwWN8/maxresdefault.jpg")
		
	Add_Dir( 
		name="Doc McStuffins", url=BASE+YOUTUBE_CHANNEL_ID_12+"/", folder=True,
		icon="https://wallpapercave.com/wp/MBv5RKJ.jpg")
		
	Add_Dir( 
		name="Peppa Pig", url=BASE+YOUTUBE_CHANNEL_ID_13+"/", folder=True,
		icon="http://4.bp.blogspot.com/-sWXI8YNcghU/VWoSOTtA18I/AAAAAAAAOqU/rk4kzhAwFto/s1600/Peppa+Pig+HD+Wallpapers7.jpg")
		
	Add_Dir( 
		name="Thundercats", url=BASE+YOUTUBE_CHANNEL_ID_14+"/", folder=True,
		icon="http://news.thundercats.ws/wp-content/uploads/sites/6/2011/03/Thundercats-Wallpaper-1-HD_1299385920.jpg")

	Add_Dir( 
		name="He Man", url=BASE+YOUTUBE_CHANNEL_ID_15+"/", folder=True,
		icon="http://3.bp.blogspot.com/-W1_DVYOJcew/ToX0blpFP1I/AAAAAAAABR0/zZb2sXig528/s1600/He-Man-High-Resolution-wallpapers.stillmaza.com-3.jpg")
		
	Add_Dir( 
		name="Classic Cartoons", url=BASE+YOUTUBE_CHANNEL_ID_16+"/", folder=True,
		icon="http://st.gdefon.com/wallpapers_original/wallpapers/337499_muzyka_chyorno-belye_stil_1920x1200_(www.GdeFon.ru).jpg")
	
	Add_Dir( 
		name="Justice League", url=BASE+YOUTUBE_CHANNEL_ID_17+"/", folder=True,
		icon="https://wallpapercave.com/wp/phon4oY.jpg")
	
	
	


@route(mode='koding_settings')
def Koding_Settings():
    Open_Settings()

@route(mode='simple_dialog', args=['title','msg'])
def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)



if __name__ == "__main__":
    Run(default='main_menu')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))