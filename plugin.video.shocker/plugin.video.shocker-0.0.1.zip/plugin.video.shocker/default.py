# -*- coding: utf-8 -*-
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Addon: Shocker
# Author: Gracie and Skeletor


import os          
import xbmc        
import xbmcaddon   
import xbmcplugin  


from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File


debug        = Addon_Setting(setting='debug')     
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 




from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File

BASE  = "plugin://plugin.video.youtube/playlist/"

YOUTUBE_CHANNEL_ID_1 = "PLP_Ikgpz6_jO00o4rNal8xQD1KZvSkl9w"
YOUTUBE_CHANNEL_ID_2 = "PLP_Ikgpz6_jOtpVpJ8TGgXS3YcLGM9Nsf"
YOUTUBE_CHANNEL_ID_3 = "PLP_Ikgpz6_jOVCX6XuGgNJKWcTbGMty87"
YOUTUBE_CHANNEL_ID_4 = "PLP_Ikgpz6_jNDXqtsjMSuZ6rR4nVHzZjj"
YOUTUBE_CHANNEL_ID_5 = "PLP_Ikgpz6_jM924ejDV7M8GV0T1VFKTGw"
YOUTUBE_CHANNEL_ID_6 = "PLP_Ikgpz6_jM4iWN45VV-aiOag0ETGLMt"
YOUTUBE_CHANNEL_ID_7 = "PLP_Ikgpz6_jO8n53AS6-7brMAyUxUcz6f"


@route(mode='main_menu')
def Main_Menu():
	Add_Dir( 
        name="In The Zone", url=BASE+YOUTUBE_CHANNEL_ID_1+"/", folder=True,
        icon="https://archive.org/download/inthezone/inthezone.jpg")		
	
	Add_Dir( 
        name="Open Your Mind", url=BASE+YOUTUBE_CHANNEL_ID_2+"/", folder=True,
        icon="https://archive.org/download/openyourmind/openyourmind.jpg")		
	
	Add_Dir( 
        name="Nerd Heaven", url=BASE+YOUTUBE_CHANNEL_ID_3+"/", folder=True,
        icon="https://archive.org/download/Shocker_20170930_2042/nerd.jpg")
		
	Add_Dir( 
        name="Ricky Bobby", url=BASE+YOUTUBE_CHANNEL_ID_4+"/", folder=True,
        icon="https://archive.org/download/rickybob/rickybob.jpg")
	
	Add_Dir( 
        name="LMAO", url=BASE+YOUTUBE_CHANNEL_ID_5+"/", folder=True,
        icon="https://archive.org/download/lmfao_201709/lmfao.jpg")
	
	Add_Dir( 
        name="80's Cartoons", url=BASE+YOUTUBE_CHANNEL_ID_6+"/", folder=True,
        icon="https://archive.org/download/Shocker_20170930/kids.jpg")
	
	Add_Dir( 
        name="Serial Killers", url=BASE+YOUTUBE_CHANNEL_ID_7+"/", folder=True,
        icon="https://archive.org/download/serial_201709/serial.jpg")
		


@route(mode='koding_settings')
def Koding_Settings():
    Open_Settings()

@route(mode='simple_dialog', args=['title','msg'])
def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)

if __name__ == "__main__":
    Run(default='main_menu')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))