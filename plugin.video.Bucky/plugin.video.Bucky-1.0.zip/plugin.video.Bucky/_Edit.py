import xbmcaddon

MainBase = 'https://dl.dropboxusercontent.com/s/jkxcmi8pyoo97ke/home.txt?dl=0'
addon = xbmcaddon.Addon('plugin.video.Bucky')