# -*- coding: utf-8 -*-




# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Addon: My YouTube Add-on
# Author: Add your name here


import os           
import xbmc      
import xbmcaddon    
import xbmcplugin   





from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File




debug        = Addon_Setting(setting='debug')      
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

BASE  = "plugin://plugin.video.youtube/playlist/"


YOUTUBE_CHANNEL_ID_1 = "PL991qh8jWvSeq9ngAHz-UDynkxv-IivcJ"
YOUTUBE_CHANNEL_ID_2 = "PL991qh8jWvSf4kR8TSK7PrPIWTweLckOQ"
YOUTUBE_CHANNEL_ID_3 = "PL991qh8jWvSdvXZGfdtopFXLZ6Vwmh9op"
YOUTUBE_CHANNEL_ID_4 = "PL991qh8jWvSfwyNbE-Yes2nEOa_mjhQbV"
YOUTUBE_CHANNEL_ID_5 = "PL991qh8jWvScHPzv6-b444OxgeUX6XNQF"
YOUTUBE_CHANNEL_ID_6 = "PL991qh8jWvSc0MdzooD3_neT-MaPMQhTP"
YOUTUBE_CHANNEL_ID_7 = "PL991qh8jWvSdEg7omYWW3s3qZRTAot5Oi"
YOUTUBE_CHANNEL_ID_8 = "PL991qh8jWvScvkDSHKKmI4Dx8psNh7POl"
YOUTUBE_CHANNEL_ID_9 = "PL991qh8jWvScchO6pXncdQuiEE25hFEMq"
YOUTUBE_CHANNEL_ID_10 ="PL991qh8jWvSfmBfmD-XmhHiOTYYQRljBl"

@route(mode='main_menu')
def Main_Menu():
	Add_Dir( 
        name="Try Not To Laugh", url=BASE+YOUTUBE_CHANNEL_ID_1+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTBlM101gesR1DpHPKEXeBXW6Acu8QCSpmLUVYMeC-P0ijLcwK4")

	Add_Dir( 
        name="The Floor is Lava", url=BASE+YOUTUBE_CHANNEL_ID_2+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRsxUKKxx_Kdaj92QnvzM30qALjm_lOgiovuLpzSaNV8PdQx0Kprg")
		
	Add_Dir( 
		name="Roblox Videos", url=BASE+YOUTUBE_CHANNEL_ID_3+"/", folder=True,
		icon="https://images.rbxcdn.com/d66ae37d46e00a1ecacfe9531986690a.jpg")
	
	Add_Dir( 
		name="Try Not To Sing", url=BASE+YOUTUBE_CHANNEL_ID_4+"/", folder=True,
		icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR3qySAPLU_AJX5KHUURIttR76bF4Tv1UzOkx5p7mW2ZvpfvmU9xg")
		
	Add_Dir( 
		name="Satisfying Videos", url=BASE+YOUTUBE_CHANNEL_ID_5+"/", folder=True,
		icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRXbSPsBuZeBsVxsurXOVIsJY29FC2UkaBhwkWjX0G-lRwXg1e6")	
	
	Add_Dir( 
        name="Movie Star Planet Videos", url=BASE+YOUTUBE_CHANNEL_ID_6+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTGGpgWhKS5WbwFc36qAHSIKbHkyMjRytR4nptkFD2tFWvPoQT8Aw")
	
	Add_Dir( 
        name="My Favorite Music", url=BASE+YOUTUBE_CHANNEL_ID_7+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR9dJ0xMQhi73UAKgDcvRng3Sle_sCKsEnhNRhrTb3655tDnJ263Q")
	
	Add_Dir( 
        name="Venturian Tales", url=BASE+YOUTUBE_CHANNEL_ID_8+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTWbehueO5iHfERx-anQoW-WOI4H1UP7BkdFDs6NW4NJUnTS5KH")
	
	Add_Dir( 
        name="Real Life Challenges", url=BASE+YOUTUBE_CHANNEL_ID_9+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR1-e3Z7ElZixUiax0AIyZrH9lO0R6M5SvZflN2e1FL00zI-MXi")
	
	Add_Dir( 
        name="Pippy's Picks", url=BASE+YOUTUBE_CHANNEL_ID_10+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTns5QD3GOzKZBVHgLaqJSY7E8xXb66QkGAhBEVn-Z7WrNzf5X_Jw")

# A basic OK Dialog
@route(mode='koding_settings')
def Koding_Settings():
    Open_Settings()
#----------------------------------------------------------------
# A basic OK Dialog
@route(mode='simple_dialog', args=['title','msg'])
def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)
#----------------------------------------------------------------


if __name__ == "__main__":
    Run(default='main_menu')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))