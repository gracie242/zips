# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Addon: Xtreme
# Author: Loose Cannon


import os           
import xbmc      
import xbmcaddon    
import xbmcplugin   

from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File

debug        = Addon_Setting(setting='debug')      
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 


BASE  = "plugin://plugin.video.youtube/playlist/"
YOUTUBE_CHANNEL_ID_1 = "PLAztR2OLm6oTNr9VgHKUndrkIBAKGeJuV"
YOUTUBE_CHANNEL_ID_2 = "PLAztR2OLm6oQT-HKrbnAcvUiP5O0FE0BN"
YOUTUBE_CHANNEL_ID_3 = "PLAztR2OLm6oQsPTk8yObS-tAlhwxKJqhI"
YOUTUBE_CHANNEL_ID_4 = "PLAztR2OLm6oSNbRkYrmxpNHrowMbIcE7d"
YOUTUBE_CHANNEL_ID_5 = "PLAztR2OLm6oQp6NBK33Fct9xTVV6z71R0"
YOUTUBE_CHANNEL_ID_6 = "PLAztR2OLm6oQtgzV25OEzewn_CqKE5s7X"
YOUTUBE_CHANNEL_ID_7 = "PLAztR2OLm6oSOCO9NpvMsrPQSzKMHS9r7"
YOUTUBE_CHANNEL_ID_8 = "PLAztR2OLm6oT_j_Ykqsd68jaFxEiEpl7D"
YOUTUBE_CHANNEL_ID_9 = "PLAztR2OLm6oRGyJKJw03lEcwHD-TTQeAe"
YOUTUBE_CHANNEL_ID_10 = "PLAztR2OLm6oShw5Z3DIPkBl_a8m9sZyJr"
YOUTUBE_CHANNEL_ID_11 = "PLAztR2OLm6oRjujYLF6nihRuuLo2mP3M2"

@route(mode='main_menu')
def Main_Menu():
	Add_Dir( 
        name="Xtreme Wilderness", url=BASE+YOUTUBE_CHANNEL_ID_1+"/", folder=True,
        icon="https://i.imgur.com/8oACm4c.png")

	Add_Dir( 
        name="Xtreme Outback", url=BASE+YOUTUBE_CHANNEL_ID_2+"/", folder=True,
        icon="https://i.imgur.com/SYsZGEX.png")
		
	Add_Dir( 
        name="Xtreme Nature", url=BASE+YOUTUBE_CHANNEL_ID_3+"/", folder=True,
        icon="https://i.imgur.com/lYx9hnB.jpg")
		
	Add_Dir( 
        name="Xtreme Survival", url=BASE+YOUTUBE_CHANNEL_ID_4+"/", folder=True,
        icon="https://i.imgur.com/ybqrZ71.jpg")

	Add_Dir( 
        name="Wild Amazon", url=BASE+YOUTUBE_CHANNEL_ID_5+"/", folder=True,
        icon="https://i.imgur.com/XWIgX4Y.png")	
		
	Add_Dir( 
        name="Wild Asia", url=BASE+YOUTUBE_CHANNEL_ID_6+"/", folder=True,
        icon="https://i.imgur.com/gecSKfi.png")

	Add_Dir( 
        name="Artic Adventure", url=BASE+YOUTUBE_CHANNEL_ID_7+"/", folder=True,
        icon="https://i.imgur.com/lVRUIDJ.jpg")
		
	Add_Dir( 
        name="Wild Africa", url=BASE+YOUTUBE_CHANNEL_ID_8+"/", folder=True,
        icon="https://i.imgur.com/AfRxriP.jpg")	
		
	Add_Dir( 
        name="From the Deep", url=BASE+YOUTUBE_CHANNEL_ID_9+"/", folder=True,
        icon="https://i.imgur.com/FFQ3prv.png")

	Add_Dir( 
        name="White Water", url=BASE+YOUTUBE_CHANNEL_ID_10+"/", folder=True,
        icon="https://i.imgur.com/8n9xBw5.jpg")	
		
	Add_Dir( 
        name="Xtreme Outdoors", url=BASE+YOUTUBE_CHANNEL_ID_11+"/", folder=True,
        icon="https://i.imgur.com/ChSadUF.jpg")	

	
	
@route(mode='koding_settings')
def Koding_Settings():
    Open_Settings()

	
@route(mode='simple_dialog', args=['title','msg'])
def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)


if __name__ == "__main__":
    Run(default='main_menu')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))