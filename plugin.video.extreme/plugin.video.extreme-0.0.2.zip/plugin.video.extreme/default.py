# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Addon: Extreme Sports
# Author: Gracie


import os           
import xbmc      
import xbmcaddon    
import xbmcplugin   

from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File

debug        = Addon_Setting(setting='debug')      
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 


BASE  = "plugin://plugin.video.youtube/playlist/"
YOUTUBE_CHANNEL_ID_1 = "PLAztR2OLm6oSTdEwjM1o2oiLxQ-_VBVRD"
YOUTUBE_CHANNEL_ID_2 = "PLAztR2OLm6oSeeph3C4M3kEisVRYG9JWh"
YOUTUBE_CHANNEL_ID_3 = "PLAztR2OLm6oRcU1GcjLx8N6SM235B-SXI"
YOUTUBE_CHANNEL_ID_4 = "PLAztR2OLm6oQLkKa-6XAq7MwqmY8RUhNS"
YOUTUBE_CHANNEL_ID_5 = "PLAztR2OLm6oT8Vyyllivd5XqkLW4P_ggf"
YOUTUBE_CHANNEL_ID_6 = "PLAztR2OLm6oQQ6Id7ITf0nI2jlWS8b5yf"
YOUTUBE_CHANNEL_ID_7 = "PLAztR2OLm6oTlCezzDXAEXCKXXqPlQPLQ"
YOUTUBE_CHANNEL_ID_8 = "PLAztR2OLm6oTJ0kkGADZ6oDc8mrEpR_JD"
YOUTUBE_CHANNEL_ID_9 = "PLAztR2OLm6oQ94K6_9Ys_816COfQpZD66"
YOUTUBE_CHANNEL_ID_10 = "PLAztR2OLm6oRlQGJYJR7yNGk_nL0r69hZ"
YOUTUBE_CHANNEL_ID_11 = "PLAztR2OLm6oR5ljuhbRrZLuv_RgIbVXSL"
YOUTUBE_CHANNEL_ID_12 = "PLAztR2OLm6oT1YvJ7w2IWs4nhlMIFCmPM"
YOUTUBE_CHANNEL_ID_13 = "PLAztR2OLm6oS-TAGEyakZfH448jvRrsB9"
YOUTUBE_CHANNEL_ID_14 = "PLAztR2OLm6oS0NYQCAiYe7ItcH3xpGD7s" 
YOUTUBE_CHANNEL_ID_15 = "PLAztR2OLm6oQ56ZNwp7Xo5l6gHAAYam-M"
YOUTUBE_CHANNEL_ID_16 = "PLAztR2OLm6oTFeRNZlCqjca5S7yemXd83" 
YOUTUBE_CHANNEL_ID_17 = "PLAztR2OLm6oReXfQPiERCY8JcuZrrmO5p"

@route(mode='main_menu')
def Main_Menu():
	Add_Dir( 
        name="Red Bull Signature Series", url=BASE+YOUTUBE_CHANNEL_ID_1+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqO6yfUlemD_n4wcMpZXFlRxJNjsD-YfLX0EEwPLURUPg9yy_tNg")

	Add_Dir( 
        name="Drag Racing", url=BASE+YOUTUBE_CHANNEL_ID_2+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQPfaln5oKsbUWqNOZrp_6A_tGaQ803cuWNE7XVyi5hMS75_k9kLQ")
		
	Add_Dir( 
		name="Bodyboarding", url=BASE+YOUTUBE_CHANNEL_ID_3+"/", folder=True,
		icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ8HwLTVYhiJftwu4IlCmOTL3CYWvSFmmetEKuFTtvVfnseIu4i")
		
	Add_Dir( 
		name="Rally X", url=BASE+YOUTUBE_CHANNEL_ID_4+"/", folder=True,
		icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTIZDnVA5uqOcu6EVGp_lBoDaXni-3pzSn24O7BzdEqYVRuKxBE")
		
	Add_Dir( 
		name="Free Climbling", url=BASE+YOUTUBE_CHANNEL_ID_5+"/", folder=True,
		icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS0lLXXwSg78L2h4UhR0b_NgTuGeuEexFbWsg32s6454DI683jn")	
	
	Add_Dir( 
        name="Ice Speedway", url=BASE+YOUTUBE_CHANNEL_ID_6+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1JGEcroj8lgy56ekGNbfpUdfJUYYXNm8CLLxOgpO2bS8k7b4RDQ")
	
	Add_Dir( 
        name="Kite Surfing", url=BASE+YOUTUBE_CHANNEL_ID_7+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRctULO8rMWh5j1zVt5PzYkFu06Z3zgGV9KzX4uAsRXjPmA7US-PA")
			
	Add_Dir( 
        name="Nascar", url=BASE+YOUTUBE_CHANNEL_ID_8+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYBT7yx7MrThcq67_6bzKp4Glwh3d9mH-vdWy8kqXKS3ChpY42ag")
		
	Add_Dir( 
        name="Jet Ski", url=BASE+YOUTUBE_CHANNEL_ID_9+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSUEhwytyLRCyOkHsJ3LOCYx5mwhdZob5Af9Go7FlmZypBcoxo7Cg")
	
	Add_Dir( 
        name="Power Boat", url=BASE+YOUTUBE_CHANNEL_ID_10+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSsy4dIK-6PMD6496MyQ4ViTMXMnj3YFF5wN0IwyI6R-0RCwsD2qA")
			
	Add_Dir( 
        name="Motor X", url=BASE+YOUTUBE_CHANNEL_ID_11+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR82SJdhFM1GYEc0zw6DbvNoDqbruHh0aG4koIhD-Ad0yUtZaIhSw")
			
	Add_Dir( 
        name="Mountain Biking", url=BASE+YOUTUBE_CHANNEL_ID_12+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQe51WixOdakN1eAWZffr-Y1285mDsMnU1A-KzoLAbk2SIZvzYrxQ")
					
	Add_Dir( 
        name="Snowboarding", url=BASE+YOUTUBE_CHANNEL_ID_13+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTcmBLC1DVa1ixEkZ5IQjPglVU_zMU1w5JUNh8i7oKMuwHKh-sx")
					
	Add_Dir( 
        name="Wakeboarding", url=BASE+YOUTUBE_CHANNEL_ID_14+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQQbhNBCr-3QYLePs5vsKGrophM5AaN5Y4bZYeLjIYSs8I8ojuHGA")
					
	Add_Dir( 
        name="Extreme Flix", url=BASE+YOUTUBE_CHANNEL_ID_15+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQjxNI6zzKbp7ZNp5XNBZhJ4nc63CDBpovxG0bQlm3vXR3hLU4cg")
					
	Add_Dir( 
        name="Mountain Boarding", url=BASE+YOUTUBE_CHANNEL_ID_16+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQEB338xNs4VQVRN7WlN7BrL6LFGbX_LE15vesE_EDodMm7_7MfRg")
					
	Add_Dir( 
        name="Dog Sled", url=BASE+YOUTUBE_CHANNEL_ID_17+"/", folder=True,
        icon="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTsffosBMB7-OsPf1dA8s0qFndfh0shqlSxYKOxGZOkpWlCWCm-")
		
		
	

@route(mode='koding_settings')
def Koding_Settings():
    Open_Settings()

	
@route(mode='simple_dialog', args=['title','msg'])
def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)


if __name__ == "__main__":
    Run(default='main_menu')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))